# 🏦 Loan Management System (Django Project)

A simple but powerful **Loan Management System** built with Django.  
It allows users to securely log in, manage loans, perform automatic calculations, and visualize data interactively using Chart.js.

---

## 🚀 Features

### 🧱 Core Functionalities
- Add, Edit, Delete, and View Loans
- Automatic computation of:
  - Monthly Payment (EMI)
  - Total Payment
- User authentication (Login / Logout)
- Secure restricted access with `@login_required`

### 📊 Data Analytics Dashboard
- Interactive Chart.js visualizations
- Dynamic filters:
  - Filter by loan amount
  - Switch between **Loan Amount** and **Interest Rate**
  - Change chart types (Bar, Line, Pie, Doughnut)
  - Resize charts in real time
- Professional dashboard layout and responsive UI

---

## ⚙️ Tech Stack

| Component | Technology Used |
|------------|-----------------|
| Backend | Django 5.2 |
| Database | SQLite3 |
| Frontend | HTML, CSS, Chart.js |
| Authentication | Django’s built-in User model |
| Visualization | Chart.js with dynamic filters |

---

## 🧩 Installation & Setup

### 1️⃣ Clone or Extract
If submitted as a ZIP:
```bash
unzip loanweb_project.zip
cd loanweb
