from django.db import models

class Loan(models.Model):
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    rate = models.DecimalField(max_digits=5, decimal_places=2)
    duration = models.IntegerField()  # in months
    monthly_payment = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    total_payment = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    date_created = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        """Automatically calculate monthly & total payments before saving."""
        if self.amount and self.rate and self.duration:
            principal = float(self.amount)
            rate = float(self.rate) / 100 / 12
            months = int(self.duration)

            # Avoid division by zero
            if rate > 0:
                monthly = principal * rate * ((1 + rate) ** months) / (((1 + rate) ** months) - 1)
            else:
                monthly = principal / months

            total = monthly * months

            self.monthly_payment = round(monthly, 2)
            self.total_payment = round(total, 2)

        super().save(*args, **kwargs)

    def __str__(self):
        return f"Loan {self.id} - {self.amount} @ {self.rate}%"
