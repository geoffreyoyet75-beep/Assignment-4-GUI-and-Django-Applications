from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.db.models import Sum, Avg, Q
from .models import Loan
from .forms import LoanForm


# ---------------- AUTHENTICATION ---------------- #

def login_user(request):
    """Handles user login"""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('loan_list')
        else:
            messages.error(request, 'Invalid username or password')
    return render(request, 'login.html')


def logout_user(request):
    """Logs out the user and redirects to login page"""
    logout(request)
    return redirect('login')


# ---------------- LOAN MANAGEMENT ---------------- #

@login_required
def loan_list(request):
    """Displays all loans with summary dashboard"""
    query = request.GET.get('q')
    loans = Loan.objects.all().order_by('-date_created')

    if query:
        loans = loans.filter(
            Q(amount__icontains=query) |
            Q(rate__icontains=query) |
            Q(duration__icontains=query)
        )

    total_loans = loans.count()
    total_amount = loans.aggregate(Sum('amount'))['amount__sum'] or 0
    average_rate = loans.aggregate(Avg('rate'))['rate__avg'] or 0

    # Data for chart on main dashboard
    loan_ids = [loan.id for loan in loans]
    amounts = [float(loan.amount) for loan in loans]
    rates = [float(loan.rate) for loan in loans]

    context = {
        'loans': loans,
        'query': query,
        'total_loans': total_loans,
        'total_amount': round(total_amount, 2),
        'average_rate': round(average_rate, 2),
        'loan_ids': loan_ids,
        'amounts': amounts,
        'rates': rates,
    }
    return render(request, 'loan_list.html', context)


@login_required
def add_loan(request):
    """Add a new loan with automatic calculations"""
    if request.method == 'POST':
        form = LoanForm(request.POST)
        if form.is_valid():
            loan = form.save(commit=False)
            rate = loan.rate / 100 / 12
            n = loan.duration
            if rate == 0:
                monthly_payment = loan.amount / n
            else:
                monthly_payment = loan.amount * rate * (1 + rate)**n / ((1 + rate)**n - 1)
            total_payment = monthly_payment * n
            loan.monthly_payment = round(monthly_payment, 2)
            loan.total_payment = round(total_payment, 2)
            loan.save()
            messages.success(request, "Loan added successfully.")
            return redirect('loan_list')
    else:
        form = LoanForm()
    return render(request, 'loan_form.html', {'form': form, 'title': 'Add Loan'})


@login_required
def edit_loan(request, loan_id):
    """Edit existing loan"""
    loan = get_object_or_404(Loan, id=loan_id)
    if request.method == 'POST':
        form = LoanForm(request.POST, instance=loan)
        if form.is_valid():
            loan = form.save(commit=False)
            rate = loan.rate / 100 / 12
            n = loan.duration
            if rate == 0:
                monthly_payment = loan.amount / n
            else:
                monthly_payment = loan.amount * rate * (1 + rate)**n / ((1 + rate)**n - 1)
            total_payment = monthly_payment * n
            loan.monthly_payment = round(monthly_payment, 2)
            loan.total_payment = round(total_payment, 2)
            loan.save()
            messages.success(request, "Loan updated successfully.")
            return redirect('loan_list')
    else:
        form = LoanForm(instance=loan)
    return render(request, 'loan_form.html', {'form': form, 'title': 'Edit Loan'})


@login_required
def delete_loan(request, loan_id):
    """Delete a loan"""
    loan = get_object_or_404(Loan, id=loan_id)
    loan.delete()
    messages.success(request, "Loan deleted successfully.")
    return redirect('loan_list')


# ---------------- ANALYTICS PAGE ---------------- #

@login_required
def analytics(request):
    """Separate analytics dashboard"""
    loans = Loan.objects.all()
    loan_ids = [loan.id for loan in loans]
    amounts = [float(loan.amount) for loan in loans]
    rates = [float(loan.rate) for loan in loans]

    return render(request, 'analytics.html', {
        'loan_ids': loan_ids,
        'amounts': amounts,
        'rates': rates,
    })
