from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_user, name='login'),
    path('logout/', views.logout_user, name='logout'),
    path('', views.loan_list, name='loan_list'),
    path('add/', views.add_loan, name='add_loan'),
    path('edit/<int:loan_id>/', views.edit_loan, name='edit_loan'),
    path('delete/<int:loan_id>/', views.delete_loan, name='delete_loan'),
    path('analytics/', views.analytics, name='analytics'),
]
